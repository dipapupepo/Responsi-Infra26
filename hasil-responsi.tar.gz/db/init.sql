CREATE TABLE students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nim VARCHAR(20),
    nama VARCHAR(100)
);

INSERT INTO students (nim, nama)
VALUES (
    'H1H024019',
    'Difa Tamaya'
);

